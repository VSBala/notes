document.addEventListener("DOMContentLoaded", function () {
    function filterTable() {
        let table = document.getElementById("dataTable");
        let rows = Array.from(table.rows).slice(1);

        rows.forEach(row => {
            let cells = row.cells;
            let showRow = true;

            document.querySelectorAll(".filter-input").forEach((input, index) => {
                let filterValue = input.value.trim().toLowerCase();
                let cell = cells[index];
                let cellValue = cell.innerText.trim().toLowerCase();

                // Clear previous highlights
                cell.innerHTML = cell.innerText;

                if (!filterValue) return; // Skip empty filters

                let conditions = filterValue.split(/\s*OR\s*/i); // Split by "OR" with spaces ignored
                let matchFound = conditions.some(condition => {
                    // Handle blank/null values
                    if (condition.toLowerCase() === "blank" && (cellValue === "" || cellValue.trim() === "")) {
                        return true;
                    }

                    // Convert * to regex .* and ? to .
                    condition = ".*" + condition.replace(/\*/g, ".*").replace(/\?/g, ".") + ".*";
                    let regex = new RegExp(condition, "i");

                    return regex.test(cellValue);
                });

                if (!matchFound) {
                    showRow = false;
                }
            });

            row.style.display = showRow ? "" : "none";
        });
    }

    document.querySelectorAll(".filter-input").forEach(input => {
        input.addEventListener("keyup", filterTable);
    });
});
