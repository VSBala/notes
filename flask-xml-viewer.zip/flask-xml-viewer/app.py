from flask import Flask, render_template, request
import xmltodict

app = Flask(__name__)

def parse_xml():
    with open("data.xml", "r") as file:
        data = xmltodict.parse(file.read())["data"]["entry"]
    return data

@app.route("/", methods=["GET", "POST"])
def index():
    entries = parse_xml()
    headers = entries[0].keys() if entries else []  # Extract column headers dynamically

    return render_template("index.html", entries=entries, headers=headers)

if __name__ == "__main__":
    app.run(debug=True)