import xml.etree.ElementTree as ET
import re

def wildcard_to_regex(pattern):
    pattern = re.escape(pattern)
    pattern = pattern.replace(r"\*", ".*").replace(r"\?", ".")
    return f"^{pattern}$"

def match_with_wildcard(text, pattern):
    regex = re.compile(wildcard_to_regex(pattern))
    return bool(regex.match(text))

def parse_and_filter_xml(file_path):
    try:
        tree = ET.parse(file_path)
        root = tree.getroot()
        headers = set()
        rows = []

        for elem in root:
            row = {}
            row.update(elem.attrib)
            for child in elem:
                row[child.tag] = child.text
            headers.update(row.keys())
            rows.append(row)

        headers = sorted(headers)

        if not rows:
            print("No data found in the XML.")
            return

        print("\nAvailable fields for filtering:")
        for h in headers:
            print(f"- {h}")
        
        field = input("\nEnter the field name to filter by (or press Enter to skip): ").strip()
        if field and field not in headers:
            print("Invalid field name. Showing all data.")
            field = None

        pattern = ""
        if field:
            pattern = input("Enter the wildcard pattern to filter by (e.g., 'Jo*', '?ike'): ").strip()

        print("\nFiltered Results:\n")
        print(" | ".join(headers))
        print("-" * (len(headers) * 15))

        for row in rows:
            value = row.get(field, "") if field else None
            if not field or (value and match_with_wildcard(value, pattern)):
                print(" | ".join([row.get(h, "") or "" for h in headers]))

    except ET.ParseError as e:
        print(f"XML parsing error: {e}")
    except FileNotFoundError:
        print("File not found. Please check the file path.")

# Example usage:
if __name__ == "__main__":
    parse_and_filter_xml("resources/sample.xml")
